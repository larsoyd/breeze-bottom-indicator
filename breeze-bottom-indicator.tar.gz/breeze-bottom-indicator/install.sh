#!/usr/bin/env bash
# install.sh — install / uninstall the breeze-bottom-indicator Plasma desktop theme.
#
# Plasma 6 / KF6 only: this theme uses metadata.json + plasmarc, which Plasma 5
# does not read (it expects metadata.desktop). The reload path therefore only
# targets Plasma 6 (kquitapp6, plasma-plasmashell.service); no Plasma-5 fallbacks.
#
# Default: per-user install to $XDG_DATA_HOME/plasma/desktoptheme/breeze-bottom-indicator/
# Use --system for /usr/share/plasma/desktoptheme/...
#
# Ships only the runtime artifacts (metadata.json, plasmarc, *.svgz tree).
# Excludes development cruft: tasks.svg, tasks.svg.*, tasks.svgz.*, *.orig,
# round-task-caps.zsh, this script.

set -euo pipefail
IFS=$'\n\t'

# ---------------------------------------------------------------- constants ---
readonly THEME_ID="breeze-bottom-indicator"
readonly THEME_NAME="Breeze Bottom Indicator"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
readonly SCRIPT_DIR
readonly SRC="$SCRIPT_DIR"

# ---------------------------------------------------------------- defaults ---
mode="user"          # user | system
prefix=""            # explicit override of install root
do_install=1
do_apply=0
do_reload=1
do_cache_clean=1
dry_run=0

# ---------------------------------------------------------------- helpers ---
if [[ -t 2 ]]; then
  c_red=$'\e[31m'; c_yel=$'\e[33m'; c_grn=$'\e[32m'; c_dim=$'\e[2m'; c_off=$'\e[0m'
else
  c_red=""; c_yel=""; c_grn=""; c_dim=""; c_off=""
fi

info() { printf '%s==>%s %s\n' "$c_grn" "$c_off" "$*"; }
warn() { printf '%swarn:%s %s\n' "$c_yel" "$c_off" "$*" >&2; }
err()  { printf '%serror:%s %s\n' "$c_red" "$c_off" "$*" >&2; }
die()  { err "$*"; exit 1; }

run() {
  if (( dry_run )); then
    printf '%s$ %s%s\n' "$c_dim" "$*" "$c_off"
  else
    "$@"
  fi
}

need() {
  command -v "$1" >/dev/null 2>&1 || die "required command not found: $1"
}

usage() {
  cat <<EOF
Install the "$THEME_NAME" Plasma desktop theme.

Usage:
  $(basename "$0") [options]

Modes (default: install for current user):
  --system            Install system-wide to /usr/share (uses sudo if needed)
  --prefix=DIR        Install under DIR/share/plasma/desktoptheme/ instead
  --uninstall         Remove the installed theme

Behaviour after install:
  --apply             Set "$THEME_ID" as the active Plasma desktop theme
  --no-reload         Don't restart plasmashell after install/uninstall
  --no-cache-clean    Don't wipe ~/.cache/plasma{-svgelements,_theme}_* caches

Other:
  -n, --dry-run       Print actions without executing them
  -h, --help          Show this help
EOF
}

# ---------------------------------------------------------------- argv ---
for arg in "$@"; do
  case "$arg" in
    --system)         mode="system" ;;
    --prefix=*)       mode="prefix"; prefix="${arg#--prefix=}" ;;
    --uninstall)      do_install=0 ;;
    --apply)          do_apply=1 ;;
    --no-reload)      do_reload=0 ;;
    --no-cache-clean) do_cache_clean=0 ;;
    -n|--dry-run)     dry_run=1 ;;
    -h|--help)        usage; exit 0 ;;
    *)                err "unknown option: $arg"; usage; exit 2 ;;
  esac
done

[[ -z "$prefix" || -n "${prefix//[[:space:]]/}" ]] || die "--prefix needs a value"

# ---------------------------------------------------------------- paths ---
case "$mode" in
  user)
    dest_root="${XDG_DATA_HOME:-$HOME/.local/share}/plasma/desktoptheme"
    SUDO=()
    ;;
  system)
    dest_root="/usr/share/plasma/desktoptheme"
    if (( EUID == 0 )); then SUDO=(); else
      command -v sudo >/dev/null 2>&1 || die "--system needs root or sudo"
      SUDO=(sudo)
    fi
    ;;
  prefix)
    dest_root="${prefix%/}/share/plasma/desktoptheme"
    SUDO=()
    ;;
esac
readonly dest_root
readonly DEST="$dest_root/$THEME_ID"

# ---------------------------------------------------------------- sanity ---
need rsync
need install

if (( do_install )); then
  [[ -f "$SRC/metadata.json" ]] || die "$SRC/metadata.json not found — run from repo root"
  # Cheap sanity: confirm the Id field matches what we think we're installing.
  if ! grep -q "\"Id\"[[:space:]]*:[[:space:]]*\"$THEME_ID\"" "$SRC/metadata.json"; then
    die "metadata.json Id does not match expected \"$THEME_ID\""
  fi
fi

# ---------------------------------------------------------------- core ---
do_install_action() {
  info "Installing $THEME_NAME -> $DEST"
  run "${SUDO[@]}" install -d -m 0755 "$DEST"

  # Include all directories, then only the runtime files we care about.
  # Order matters: includes are evaluated top-down, first match wins.
  # --prune-empty-dirs avoids leaving stub dirs that hold nothing.
  run "${SUDO[@]}" rsync -a --delete --prune-empty-dirs \
      --chmod=D0755,F0644 \
      --include='*/' \
      --include='metadata.json' \
      --include='plasmarc' \
      --include='*.svgz' \
      --exclude='*' \
      "$SRC"/ "$DEST"/
}

do_uninstall_action() {
  if [[ ! -d "$DEST" ]]; then
    warn "$DEST does not exist — nothing to uninstall"
    return 0
  fi
  # Be paranoid: refuse to rm -rf anything that isn't actually a theme dir.
  if [[ ! -f "$DEST/metadata.json" ]]; then
    die "$DEST exists but has no metadata.json — refusing to remove"
  fi
  info "Removing $DEST"
  run "${SUDO[@]}" rm -rf -- "$DEST"
}

clean_caches() {
  (( do_cache_clean )) || return 0
  # Scope strictly to THIS theme's caches. The two relevant prefixes, per
  # KDE/plasma-framework src/plasma/private/theme_p.cpp:
  #   plasma_theme_<id>*.kcache       -- pixmap cache
  #   plasma-svgelements-<id>*        -- svg elements cache (may be _vN suffixed)
  # ksycoca is unrelated to desktop themes and is intentionally NOT touched.
  # Caches are always per-user, even when installing system-wide.
  local cache_dir="${XDG_CACHE_HOME:-$HOME/.cache}"
  info "Clearing $THEME_ID caches in $cache_dir"
  shopt -s nullglob
  local stale=( "$cache_dir/plasma_theme_${THEME_ID}"*        \
                "$cache_dir/plasma-svgelements-${THEME_ID}"*  )
  shopt -u nullglob
  if (( ${#stale[@]} )); then
    run rm -rf -- "${stale[@]}"
  fi
}

reload_plasma() {
  (( do_reload )) || return 0
  # Only meaningful inside a running graphical session for the current user.
  if [[ -z "${WAYLAND_DISPLAY:-}${DISPLAY:-}" ]]; then
    warn "no graphical session detected — skipping plasmashell reload"
    return 0
  fi

  # This theme uses metadata.json + plasmarc, which is KF6 / Plasma 6 only
  # (Plasma 5 reads metadata.desktop). So no Plasma-5 reload paths.
  if systemctl --user list-unit-files plasma-plasmashell.service >/dev/null 2>&1 \
       && systemctl --user is-active --quiet plasma-plasmashell.service; then
    info "Restarting plasma-plasmashell.service (user unit)"
    run systemctl --user restart plasma-plasmashell.service
    return 0
  fi

  if pgrep -x plasmashell >/dev/null 2>&1; then
    info "Restarting plasmashell"
    if command -v kquitapp6 >/dev/null 2>&1; then
      run kquitapp6 plasmashell || true
    else
      warn "kquitapp6 not found — falling back to pkill"
      run pkill -x plasmashell || true
    fi
    sleep 1
    if command -v kstart >/dev/null 2>&1; then
      run setsid -f kstart plasmashell >/dev/null 2>&1 || true
    else
      run setsid -f plasmashell >/dev/null 2>&1 || true
    fi
  else
    warn "plasmashell isn't running — nothing to reload"
  fi
}

apply_theme() {
  (( do_apply )) || return 0
  if ! command -v plasma-apply-desktoptheme >/dev/null 2>&1; then
    warn "plasma-apply-desktoptheme not found — apply manually in System Settings"
    return 0
  fi
  info "Setting active desktop theme to $THEME_ID"
  run plasma-apply-desktoptheme "$THEME_ID"
}

# ---------------------------------------------------------------- run ---
if (( do_install )); then
  do_install_action
else
  do_uninstall_action
fi

clean_caches
apply_theme
reload_plasma

if (( dry_run )); then
  info "dry run — no changes made"
elif (( do_install )); then
  cat <<EOF

${c_grn}Done.${c_off} Installed to: $DEST
Activate: System Settings -> Colors & Themes -> Plasma Style -> "$THEME_NAME"
   or:   plasma-apply-desktoptheme $THEME_ID
EOF
else
  info "Uninstalled $THEME_NAME"
fi
