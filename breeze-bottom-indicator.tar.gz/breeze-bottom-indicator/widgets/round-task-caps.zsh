#!/usr/bin/env zsh
# Round only the side caps of unprefixed bottom task indicators in tasks.svg.
# Keeps the 9-slice frame bbox intact. Does not touch north/east/west groups.

set -euo pipefail

TASKS_SVG="${1:-$HOME/.local/share/plasma/desktoptheme/breeze-bottom-indicator/widgets/tasks.svg}"
TASKS_SVGZ="${TASKS_SVG}z"

if [[ ! -f "$TASKS_SVG" ]]; then
  if [[ -f "$TASKS_SVGZ" ]]; then
    gzip -dc "$TASKS_SVGZ" > "$TASKS_SVG"
  elif [[ -f "$HOME/.local/share/plasma/desktoptheme/breeze-bottom-indicator/widgets/tasks.svgz" ]]; then
    gzip -dc "$HOME/.local/share/plasma/desktoptheme/breeze-bottom-indicator/widgets/tasks.svgz" > "$TASKS_SVG"
  else
    print -u2 "ERROR: tasks.svg not found: $TASKS_SVG"
    return 1
  fi
fi

stamp=$(date +%Y%m%d-%H%M%S)
backup="${TASKS_SVG}.bak-round-caps.${stamp}"
cp -a "$TASKS_SVG" "$backup"
[[ -f "$TASKS_SVGZ" ]] && cp -a "$TASKS_SVGZ" "${TASKS_SVGZ}.bak-round-caps.${stamp}"

print "Backup written: $backup"

python3 - "$TASKS_SVG" <<'PY'
import re
import sys
from pathlib import Path

p = Path(sys.argv[1])
src = p.read_text(encoding="utf-8")

# These are the exact stock Breeze bottom cap path strings from your pasted SVG.
# The new paths keep the same approximate bbox, but round only the outward cap.
class_a = [
    (
        "bottomleft",
        "m32 18h2v3h-2z",
        "m34 18v1.5a1 1.5 0 0 1-2 0v-1.5z",
    ),
    (
        "bottomright",
        "m31 19h3v2h-3z",
        "m31 21h1.5a1.5 1 0 0 0 0-2h-1.5z",
    ),
]

class_a_states = ["focus", "normal", "hover", "attention", "progress"]

# Minimized has different transforms and slightly different original path strings.
class_b = [
    (
        "bottomleft",
        "m31.00001 18h2.99999v3h-2.99999z",
        "m34 18h-3v1.5a1.5 1.5 0 0 0 3 0z",
    ),
    (
        "bottomright",
        "m31 18.00001h3v2.99999h-3z",
        "m31 21h1.5a1.5 1.5 0 0 0 0-3h-1.5z",
    ),
]

targets = []

for state in class_a_states:
    for corner, old, new in class_a:
        targets.append((f"{state}-{corner}", old, new))

for corner, old, new in class_b:
    targets.append((f"minimized-{corner}", old, new))

patched = 0
already = 0
missing = []

for gid, old, new in targets:
    group_re = re.compile(
        r'(<g\s+id="' + re.escape(gid) + r'"[^>]*>)(.*?)(</g>)',
        re.DOTALL,
    )
    m = group_re.search(src)

    if not m:
        missing.append(gid)
        continue

    body = m.group(2)

    if f'd="{new}"' in body:
        already += 1
        print(f"  {gid}: already patched")
        continue

    if f'd="{old}"' not in body:
        missing.append(f"{gid} path changed")
        continue

    new_body = body.replace(f'd="{old}"', f'd="{new}"', 1)
    src = src[:m.start()] + m.group(1) + new_body + m.group(3) + src[m.end():]
    patched += 1
    print(f"  {gid}: patched")

if missing:
    print("\nERROR: some expected groups/path strings were not found.", file=sys.stderr)
    print("This usually means the SVG is not clean stock-bottom anymore.", file=sys.stderr)
    for item in missing:
        print(f"  - {item}", file=sys.stderr)
    sys.exit(1)

p.write_text(src, encoding="utf-8")
print(f"\nPatched {patched}, already patched {already}, expected {len(targets)}")
PY

gzip -9 -n -c "$TASKS_SVG" > "$TASKS_SVGZ"

# zsh-safe cache cleanup. (N) means no error when no files match.
rm -f ~/.cache/plasma-svgelements-*(N) ~/.cache/plasma_theme_*(N) ~/.cache/*plasma*(N)

if systemctl --user list-unit-files plasma-plasmashell.service &>/dev/null; then
  systemctl --user restart plasma-plasmashell.service
  print "Restarted plasma-plasmashell.service"
else
  kquitapp6 plasmashell || true
  sleep 1
  kstart plasmashell
  print "Restarted plasmashell with kquitapp6/kstart"
fi

print
print "Done. To revert:"
print "  cp -a '$backup' '$TASKS_SVG'"
print "  gzip -9 -n -c '$TASKS_SVG' > '$TASKS_SVGZ'"
print "  systemctl --user restart plasma-plasmashell.service"
